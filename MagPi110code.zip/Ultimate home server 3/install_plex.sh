#!/bin/sh

# Plex's repository uses HTTPS as the transport, so we need to install support
sudo apt update
sudo apt install apt-transport-https ca-certificates curl

# Get Plex's public key and add the Plex repo
curl https://downloads.plex.tv/plex-keys/PlexSign.key | sudo apt-key add -
echo deb https://downloads.plex.tv/repo/deb public main | sudo tee /etc/apt/sources.list.d/plexmediaserver.list

# Install the server
sudo apt update
sudo apt install plexmediaserver