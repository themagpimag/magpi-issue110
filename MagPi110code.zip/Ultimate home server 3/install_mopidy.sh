#!/bin/sh

# Add Mopidy repo and install
wget -q -O - https://apt.mopidy.com/mopidy.gpg | sudo apt-key add -
sudo wget -q -O /etc/apt/sources.list.d/mopidy.list https://apt.mopidy.com/buster.list
sudo apt update
sudo apt install mopidy
sudo adduser mopidy video

# Configure (be careful with this line!)
printf "[http]\nhostname = 0.0.0.0" | sudo tee -a  /etc/mopidy/mopidy.conf

# Install user interface
sudo apt install python3-pip
sudo pip3 install Mopidy-Iris
sudo pip3 install Mopidy-Local
sudo sh -c 'echo "mopidy ALL=NOPASSWD: /usr/local/lib/python3.7/dist-packages/mopidy_iris/system.sh" >> /etc/sudoers'

# Enable and start service
sudo systemctl enable mopidy
sudo systemctl start mopidy